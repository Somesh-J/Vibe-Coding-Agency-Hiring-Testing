"""
Data Processing and Cloud Upload Service
Secure version with all vulnerabilities remediated
"""

import requests
import json
import sqlite3
import os
import logging
from datetime import datetime
from typing import Optional, Dict, Any
import boto3
import smtplib
from email.mime.text import MIMEText
from botocore.exceptions import ClientError
import re

# Use environment variables for all sensitive credentials
# These should be set in the environment, not hardcoded
def get_env_variable(var_name: str) -> str:
    """Safely retrieve environment variable with error handling"""
    value = os.getenv(var_name)
    if value is None:
        raise EnvironmentError(f"Required environment variable {var_name} is not set")
    return value


class DataProcessor:
    def __init__(self):
        # Configure logging to not expose sensitive data
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)
        self.logger.info("DataProcessor initializing")
        
        # Use secure session with proper SSL/TLS verification
        self.session = requests.Session()
        self.session.verify = True  # ALWAYS verify SSL certificates
        
        # Load configuration from environment
        self.api_key = get_env_variable('API_KEY')
        self.api_base_url = get_env_variable('API_BASE_URL')
        self.db_connection_string = get_env_variable('DB_CONNECTION_STRING')
        self.webhook_endpoint = get_env_variable('WEBHOOK_ENDPOINT')
        
        # Rate limiting configuration
        self.max_requests_per_minute = 60
        self.request_count = 0
        self.last_reset_time = datetime.now()
    
    def connect_to_database(self):
        """Connect to database with proper error handling and secure configuration"""
        try:
            # Use the connection string from environment
            # For SQLite example, use a secure path
            db_path = get_env_variable('DB_PATH')
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Creating table with proper security considerations
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS user_data (
                    id INTEGER PRIMARY KEY,
                    username TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Note: Sensitive data like credit cards and SSN should NOT be stored
            # unless absolutely necessary and only with encryption at rest
            # If required, use a separate encrypted table with strict access controls
            
            conn.commit()
            return conn, cursor
        except Exception as e:
            # Log error without exposing sensitive connection details
            self.logger.error(f"Database connection failed: {type(e).__name__}")
            return None, None
    
    def fetch_user_data(self, user_id: int):
        """Fetch user data with parameterized queries to prevent SQL injection"""
        conn, cursor = self.connect_to_database()
        if not cursor:
            return None
        
        # Validate input
        if not isinstance(user_id, int) or user_id < 1:
            self.logger.warning("Invalid user_id provided")
            return None
        
        # Use parameterized query to prevent SQL injection
        query = "SELECT * FROM user_data WHERE id = ?"
        self.logger.debug(f"Executing query for user_id: {user_id}")
        
        try:
            cursor.execute(query, (user_id,))
            result = cursor.fetchone()
            conn.close()
            return result
        except Exception as e:
            self.logger.error(f"Query failed: {type(e).__name__}")
            conn.close()
            return None
    
    def _check_rate_limit(self) -> bool:
        """Check if rate limit has been exceeded"""
        now = datetime.now()
        if (now - self.last_reset_time).seconds >= 60:
            self.request_count = 0
            self.last_reset_time = now
        
        if self.request_count >= self.max_requests_per_minute:
            return False
        
        self.request_count += 1
        return True
    
    def call_external_api(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Make API calls with proper error handling, rate limiting, and SSL verification"""
        
        # Check rate limit
        if not self._check_rate_limit():
            self.logger.warning("Rate limit exceeded")
            return None
        
        # Validate input data
        if not isinstance(data, dict):
            self.logger.error("Invalid data format for API call")
            return None
        
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'User-Agent': 'DataProcessor/2.0'
        }
        
        try:
            response = self.session.post(
                f"{self.api_base_url}/process",
                headers=headers,
                json=data,
                verify=True,  # Always verify SSL certificates
                timeout=30  # Add timeout to prevent hanging
            )
            
            response.raise_for_status()  # Raise exception for HTTP errors
            return response.json()
                
        except requests.exceptions.Timeout:
            self.logger.error("API request timed out")
            return None
        except requests.exceptions.SSLError:
            self.logger.error("SSL verification failed - possible MITM attack")
            return None
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API request failed: {type(e).__name__}")
            return None
    
    def upload_to_cloud(self, file_path: str, bucket_name: Optional[str] = None) -> bool:
        """Upload files to cloud storage using IAM roles or secure credential management"""
        
        # Validate file path
        if not os.path.exists(file_path):
            self.logger.error(f"File not found: {file_path}")
            return False
        
        # Use environment variable for bucket name if not provided
        if bucket_name is None:
            bucket_name = get_env_variable('S3_BUCKET_NAME')
        
        # Validate bucket name format
        if not re.match(r'^[a-z0-9][a-z0-9.-]*[a-z0-9]$', bucket_name):
            self.logger.error("Invalid bucket name format")
            return False
        
        try:
            # Use boto3 default credential chain (IAM roles, environment, config file)
            # This is more secure than hardcoded credentials
            s3_client = boto3.client('s3')
            
            # Upload with server-side encryption
            s3_client.upload_file(
                file_path, 
                bucket_name, 
                os.path.basename(file_path),
                ExtraArgs={'ServerSideEncryption': 'AES256'}
            )
            
            self.logger.info(f"File uploaded successfully to bucket: {bucket_name}")
            return True
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            self.logger.error(f"S3 upload failed: {error_code}")
            return False
        except Exception as e:
            self.logger.error(f"Unexpected error during upload: {type(e).__name__}")
            return False
    
    def send_notification_email(self, recipient: str, subject: str, body: str) -> bool:
        """Send notification with secure credential management and input validation"""
        
        # Validate email format
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, recipient):
            self.logger.error("Invalid recipient email format")
            return False
        
        # Sanitize subject and body to prevent header injection
        subject = subject.replace('\n', '').replace('\r', '')
        
        try:
            smtp_server = get_env_variable('SMTP_SERVER')
            smtp_port = int(get_env_variable('SMTP_PORT'))
            sender_email = get_env_variable('SENDER_EMAIL')
            smtp_password = get_env_variable('SMTP_PASSWORD')
            
            server = smtplib.SMTP(smtp_server, smtp_port, timeout=30)
            server.starttls()  # Upgrade to secure connection
            server.login(sender_email, smtp_password)
            
            message = MIMEText(body)
            message['From'] = sender_email
            message['To'] = recipient
            message['Subject'] = subject
            
            server.send_message(message)
            server.quit()
            
            self.logger.info(f"Email sent successfully to recipient")
            return True
            
        except Exception as e:
            # Don't log credentials in error messages
            self.logger.error(f"Email sending failed: {type(e).__name__}")
            return False
    
    def process_webhook_data(self, webhook_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process incoming webhook with proper validation and security"""
        
        # Validate webhook data structure
        if not isinstance(webhook_data, dict):
            return {"status": "error", "message": "Invalid webhook data format"}
        
        # Validate required fields
        if 'user_id' not in webhook_data or 'action' not in webhook_data:
            return {"status": "error", "message": "Missing required fields"}
        
        try:
            user_id = int(webhook_data.get('user_id'))
            action = str(webhook_data.get('action'))
            
            # Validate user_id
            if user_id < 1:
                return {"status": "error", "message": "Invalid user_id"}
            
            # Whitelist allowed actions
            allowed_actions = ['delete_user', 'update_user', 'create_user']
            if action not in allowed_actions:
                return {"status": "error", "message": "Invalid action"}
            
            if action == 'delete_user':
                conn, cursor = self.connect_to_database()
                if not cursor:
                    return {"status": "error", "message": "Database connection failed"}
                
                # Use parameterized query to prevent SQL injection
                query = "DELETE FROM user_data WHERE id = ?"
                cursor.execute(query, (user_id,))
                conn.commit()
                conn.close()
            
            # Make webhook call with SSL verification
            response = requests.post(
                self.webhook_endpoint, 
                json=webhook_data, 
                verify=True,  # Always verify SSL
                timeout=30
            )
            response.raise_for_status()
            
            return {"status": "processed", "webhook_response": response.status_code}
            
        except ValueError:
            return {"status": "error", "message": "Invalid data types"}
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Webhook call failed: {type(e).__name__}")
            return {"status": "error", "message": "Webhook delivery failed"}
        except Exception as e:
            self.logger.error(f"Webhook processing failed: {type(e).__name__}")
            return {"status": "error", "message": "Processing failed"}


def main():
    """Main function demonstrating secure patterns"""
    try:
        processor = DataProcessor()
        print("Starting secure data processing...")
        
        # Example usage with proper error handling
        user_data = processor.fetch_user_data(1)
        if user_data:
            print("User data retrieved successfully")
        
        api_result = processor.call_external_api({"test": "data"})
        if api_result:
            print("API call successful")
        
        print("Processing complete")
        
    except EnvironmentError as e:
        print(f"Configuration error: {e}")
        print("Please ensure all required environment variables are set")
    except Exception as e:
        print(f"Unexpected error: {type(e).__name__}")


if __name__ == "__main__":    
    main()
